import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-taskmanager',
  templateUrl: './taskmanager.component.html',
  styleUrls: ['./taskmanager.component.css']
})
export class TaskmanagerComponent implements OnInit {
  
  ngOnInit() {
  }

  refresh()
  {
    window.location.reload();
  }

}
