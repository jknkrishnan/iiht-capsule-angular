export class Parent {    
    Parent_Id : number;
    Parent_Task : string;
}
