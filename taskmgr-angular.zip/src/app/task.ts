export class Task {    
    Task_Id : number;
    Parent_Id : number;
    TaskDesc : string;
    strDate : Date;
    endDate : Date;
    priority : number;
    delete_flag : number;
    parent_name : string; 
    //newstrDate : string;  
    //newendDate : string;
    
}

